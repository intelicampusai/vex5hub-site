"""
VEX V5 Hub Content Updater Lambda Function

This Lambda function fetches and aggregates VEX V5 content from external sources:
- VEX RobotEvents API (global competition data)
- Social media feeds (trending viral videos from the community)
- Technical analysis and meta breakdowns

Maintained by Team 3150N Nighthawks
Triggered by EventBridge every 4 hours.
"""

import json
import os
import logging
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Any

import boto3

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS clients
s3_client = boto3.client('s3')
cloudfront_client = boto3.client('cloudfront')

# Environment variables
DATA_BUCKET = os.environ.get('DATA_BUCKET_NAME')
CLOUDFRONT_DIST_ID = os.environ.get('CLOUDFRONT_DIST_ID')
PROJECT_NAME = os.environ.get('PROJECT_NAME', 'vex-v5-hub')

# VEX RobotEvents API configuration
VEX_API_BASE_URL = "https://www.robotevents.com/api/v2"
VEX_TEAM_NUMBER = "3150N"  # Maintainer team number (for About page data)


def handler(event: dict, context: Any) -> dict:
    """
    Main Lambda handler.
    
    Args:
        event: EventBridge event payload
        context: Lambda context
    
    Returns:
        Response with status and updated content info
    """
    logger.info(f"Content update triggered at {datetime.now(timezone.utc).isoformat()}")
    
    results = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "updates": [],
        "errors": []
    }
    
    try:
        # Fetch and update competition data
        competitions = fetch_competitions()
        if competitions:
            upload_to_s3("competitions.json", competitions)
            results["updates"].append("competitions.json")
        
        # Fetch and update upcoming events
        events = fetch_upcoming_events()
        if events:
            upload_to_s3("events.json", events)
            results["updates"].append("events.json")
        
        # Fetch team information
        team_info = fetch_team_info()
        if team_info:
            upload_to_s3("team.json", team_info)
            results["updates"].append("team.json")
        
        # Update robots/viral content (placeholder for social media integration)
        robots_content = fetch_robots_content()
        if robots_content:
            upload_to_s3("robots.json", robots_content)
            results["updates"].append("robots.json")
        
        # Invalidate CloudFront cache for data files
        if results["updates"]:
            invalidate_cache([f"/data/{f}" for f in results["updates"]])
            logger.info(f"Cache invalidated for {len(results['updates'])} files")
        
        logger.info(f"Content update completed: {json.dumps(results)}")
        
        return {
            "statusCode": 200,
            "body": json.dumps(results)
        }
        
    except Exception as e:
        logger.error(f"Content update failed: {str(e)}")
        results["errors"].append(str(e))
        return {
            "statusCode": 500,
            "body": json.dumps(results)
        }


def fetch_competitions() -> dict:
    """
    Fetch recent VEX V5 competition results globally.
    
    Returns:
        Dictionary with competition data from around the world
    """
    logger.info("Fetching global competition data...")
    
    # Note: VEX RobotEvents API requires authentication
    # For now, return placeholder structure
    # TODO: Add API key from Secrets Manager and fetch global competitions
    
    return {
        "lastUpdated": datetime.now(timezone.utc).isoformat(),
        "scope": "global",
        "competitions": [
            {
                "id": "placeholder",
                "name": "Global competition data will be fetched via RobotEvents API",
                "date": None,
                "location": None,
                "results": []
            }
        ],
        "note": "Configure VEX_API_KEY in Secrets Manager to enable live data"
    }


def fetch_upcoming_events() -> dict:
    """
    Fetch upcoming VEX V5 events worldwide, including major tournaments and Worlds.
    
    Returns:
        Dictionary with event data
    """
    logger.info("Fetching upcoming events...")
    
    return {
        "lastUpdated": datetime.now(timezone.utc).isoformat(),
        "events": [
            {
                "id": "placeholder",
                "name": "Upcoming global events will be fetched via RobotEvents API",
                "date": None,
                "location": "Worldwide",
                "type": "various"
            }
        ],
        "note": "Configure VEX_API_KEY in Secrets Manager to enable live data"
    }


def fetch_team_info() -> dict:
    """
    Fetch and update team information.
    
    Returns:
        Dictionary with team data
    """
    logger.info("Fetching team info...")
    
    return {
        "lastUpdated": datetime.now(timezone.utc).isoformat(),
        "team": {
            "number": VEX_TEAM_NUMBER,
            "name": "Nighthawks",
            "organization": "3150",
            "program": "VEX V5",
            "region": "Ontario, Canada"
        },
        "stats": {
            "note": "Stats will be populated from RobotEvents API"
        }
    }


def fetch_robots_content() -> dict:
    """
    Fetch trending robot content from the VEX V5 community via social media.
    
    Returns:
        Dictionary with robots/viral content from various teams
    """
    logger.info("Fetching community robots content...")
    
    return {
        "lastUpdated": datetime.now(timezone.utc).isoformat(),
        "viral": [
            {
                "id": "placeholder",
                "title": "Trending VEX V5 robot content from community",
                "source": "youtube",
                "url": None,
                "thumbnail": None,
                "team": "Various"
            }
        ],
        "techBreakdowns": [
            {
                "id": "placeholder",
                "title": "Meta design analysis placeholder",
                "description": "Community technical breakdowns coming soon"
            }
        ],
        "note": "Configure social media API keys to enable live content aggregation"
    }


def upload_to_s3(filename: str, data: dict) -> None:
    """
    Upload JSON data to S3 data bucket.
    
    Args:
        filename: Name of the file to upload
        data: Dictionary to upload as JSON
    """
    try:
        s3_client.put_object(
            Bucket=DATA_BUCKET,
            Key=filename,
            Body=json.dumps(data, indent=2, default=str),
            ContentType="application/json",
            CacheControl="max-age=14400"  # 4 hours
        )
        logger.info(f"Uploaded {filename} to S3")
    except Exception as e:
        logger.error(f"Failed to upload {filename}: {str(e)}")
        raise


def invalidate_cache(paths: list) -> None:
    """
    Invalidate CloudFront cache for specified paths.
    
    Args:
        paths: List of paths to invalidate
    """
    try:
        cloudfront_client.create_invalidation(
            DistributionId=CLOUDFRONT_DIST_ID,
            InvalidationBatch={
                "Paths": {
                    "Quantity": len(paths),
                    "Items": paths
                },
                "CallerReference": f"{PROJECT_NAME}-{datetime.now(timezone.utc).timestamp()}"
            }
        )
        logger.info(f"Cache invalidation requested for {paths}")
    except Exception as e:
        logger.error(f"Failed to invalidate cache: {str(e)}")
        raise
